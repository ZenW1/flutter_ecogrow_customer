package kh.com.ecogrow.ecommerce.sale.flutter_ecogrow_customer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
