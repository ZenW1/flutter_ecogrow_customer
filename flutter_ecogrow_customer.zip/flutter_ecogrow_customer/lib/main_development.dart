import 'package:flutter_ecogrow_customer/app/app.dart';
import 'package:flutter_ecogrow_customer/bootstrap.dart';

void main() {
  bootstrap(() => const App());
}
