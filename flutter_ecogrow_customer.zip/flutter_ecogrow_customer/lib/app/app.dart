export 'view/app.dart';
